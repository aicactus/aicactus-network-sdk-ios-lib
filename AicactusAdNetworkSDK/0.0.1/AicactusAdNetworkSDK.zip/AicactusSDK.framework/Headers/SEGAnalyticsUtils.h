#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// Logging

void SEGSetShowDebugLogs(BOOL showDebugLogs);
void SEGLog(NSString *format, ...);

NS_ASSUME_NONNULL_END
